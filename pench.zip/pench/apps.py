from django.apps import AppConfig


class PenchConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pench'
